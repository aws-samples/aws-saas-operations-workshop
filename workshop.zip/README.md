# README

To deploy workshop:

`cd own-account && ./deploy.sh && cd ..`

IDE details are in the output of the `SaaSOpsV2-Vscode` CloudFormation stack.

To delete the workshop:

`./delete_workshop.sh`
