# README

To deploy workshop (SaaS control plane + basic cell):

`./deploy_workshop.sh`

To load the interface commands:

`source ./test_interface.sh`

To delete the entire workshop:

`./delete_workshop.sh`
